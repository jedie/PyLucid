CREATE TABLE `%(table_prefix)sappconfig` (`id` int(11) NOT NULL auto_increment,`name` varchar(30) NOT NULL default '',`value` varchar(255) NOT NULL default '',PRIMARY KEY  (`id`),UNIQUE KEY `name` (`name`)) COMMENT='not used yet!';
INSERT INTO `%(table_prefix)sappconfig` VALUES (1,'version','1.0.11');
