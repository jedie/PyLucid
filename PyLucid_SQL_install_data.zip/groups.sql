CREATE TABLE `%(table_prefix)sgroups` (`id` int(11) NOT NULL auto_increment,`pluginID` int(11) NOT NULL default '0',`name` varchar(50) NOT NULL default '',`section` varchar(50) NOT NULL default '',`description` varchar(50) NOT NULL default '',PRIMARY KEY  (`id`),UNIQUE KEY `name` (`name`)) COMMENT='not used yet!';
INSERT INTO `%(table_prefix)sgroups` VALUES (1,0,'managePages','core','This group is able to add/edit/delete pages.');
INSERT INTO `%(table_prefix)sgroups` VALUES (2,0,'manageStyles','core','This group is able to add/edit/delete stylesheets.');
INSERT INTO `%(table_prefix)sgroups` VALUES (3,0,'manageTemplates','core','This group is able to add/edit/delete templates.');
INSERT INTO `%(table_prefix)sgroups` VALUES (4,0,'admin','user-Defined','Administratoren');
