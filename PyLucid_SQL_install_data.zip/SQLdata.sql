-- ------------------------------------------------------
-- universalized 10.08.2005, 23:34 with PyLucid's universalize SQL dump.py v0.0.1
-- ------------------------------------------------------
-- Dump created 10.08.2005, 23:32 with PyLucid's DBdump.py v0.0.1
-- ------------------------------------------------------
-- MySQL dump 10.9
--
-- Host: localhost    Database: db1017233-jensDE
-- ------------------------------------------------------
-- Server version	4.1.10a-Debian_2ubuntu0.1-log




--
-- Table structure for table `%(table_prefix)sappconfig`
--

CREATE TABLE `%(table_prefix)sappconfig` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
);

--
-- Dumping data for table `%(table_prefix)sappconfig`
--

INSERT INTO `%(table_prefix)sappconfig` VALUES (1,'version','1.0.11');

--
-- Table structure for table `%(table_prefix)sarchive`
--

CREATE TABLE `%(table_prefix)sarchive` (
  `id` int(11) NOT NULL auto_increment,
  `userID` int(11) NOT NULL default '0',
  `type` varchar(50) NOT NULL default '',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `comment` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  PRIMARY KEY  (`id`)
);

--
-- Dumping data for table `%(table_prefix)sarchive`
--


--
-- Table structure for table `%(table_prefix)sgroups`
--

CREATE TABLE `%(table_prefix)sgroups` (
  `id` int(11) NOT NULL auto_increment,
  `pluginID` int(11) NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `section` varchar(50) NOT NULL default '',
  `description` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
);

--
-- Dumping data for table `%(table_prefix)sgroups`
--

INSERT INTO `%(table_prefix)sgroups` VALUES (1,0,'managePages','core','This group is able to add/edit/delete pages.');
INSERT INTO `%(table_prefix)sgroups` VALUES (2,0,'manageStyles','core','This group is able to add/edit/delete stylesheets.');
INSERT INTO `%(table_prefix)sgroups` VALUES (3,0,'manageTemplates','core','This group is able to add/edit/delete templates.');
INSERT INTO `%(table_prefix)sgroups` VALUES (4,0,'admin','user-Defined','Administratoren');

--
-- Table structure for table `%(table_prefix)slog`
--

CREATE TABLE `%(table_prefix)slog` (
  `id` int(11) NOT NULL auto_increment,
  `timestamp` datetime default NULL,
  `sid` varchar(50) NOT NULL default '-1',
  `user_name` varchar(50) default NULL,
  `ip` varchar(50) default NULL,
  `domain` varchar(50) default NULL,
  `message` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
);

--
-- Dumping data for table `%(table_prefix)slog`
--


--
-- Table structure for table `%(table_prefix)smd5users`
--

CREATE TABLE `%(table_prefix)smd5users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `realName` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `pass1` varchar(32) NOT NULL default '',
  `pass2` varchar(32) NOT NULL default '',
  `admin` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
);

--
-- Dumping data for table `%(table_prefix)smd5users`
--


--
-- Table structure for table `%(table_prefix)spages`
--

CREATE TABLE `%(table_prefix)spages` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `title` varchar(50) default NULL,
  `parent` int(11) NOT NULL default '0',
  `position` int(11) NOT NULL default '0',
  `template` int(11) NOT NULL default '0',
  `style` int(11) NOT NULL default '0',
  `datetime` datetime default NULL,
  `markup` varchar(50) default NULL,
  `content` text,
  `keywords` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `lastupdatetime` datetime default NULL,
  `lastupdateby` int(11) default NULL,
  `showlinks` tinyint(4) NOT NULL default '1',
  `permitViewPublic` tinyint(4) NOT NULL default '1',
  `permitViewGroupID` int(11) default NULL,
  `ownerID` int(11) NOT NULL default '0',
  `permitEditGroupID` int(11) default NULL,
  PRIMARY KEY  (`id`)
);

--
-- Dumping data for table `%(table_prefix)spages`
--

INSERT INTO `%(table_prefix)spages` VALUES (1,'PyLucid','',0,1,1,1,'2004-12-07 00:00:00','textile','h3. Welcome to your new CMS Side!\r\n\r\nThis Content Management System powered by <lucidTag:powered_by/>\r\n\r\nh4. quick instructions\r\n\r\n# use the login button at the bottom of every page.\r\n# edit styles/templates\r\n\r\nh4. important\r\n\r\n# for safety reasons: delete \"install_PyLucid.py\" on your Server\r\n# be carefull change the internal sides\r\n\r\nh5. PyLucid Homepage\r\n\r\nhttp://www.jensdiemer.de/Programmieren/Python/PyLucid\r\n\r\nh5. last changes:\r\n\r\n<lucidTag:list_of_new_sides/>','Jens Diemer, PyLucid, CMS','','2005-08-10 23:31:01',3,1,1,1,1,1);
INSERT INTO `%(table_prefix)spages` VALUES (2,'SideMap','',0,1,1,1,'2005-08-10 22:43:53','textile','<lucidTag:SiteMap/>','','','2005-08-10 22:44:06',3,1,1,1,1,1);

--
-- Table structure for table `%(table_prefix)spages_internal`
--

CREATE TABLE `%(table_prefix)spages_internal` (
  `name` varchar(50) NOT NULL default '',
  `markup` varchar(50) NOT NULL default '',
  `content` text NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY  (`name`)
);

--
-- Dumping data for table `%(table_prefix)spages_internal`
--

INSERT INTO `%(table_prefix)spages_internal` VALUES ('login_form','none','<h2>PyLucid - LogIn:</h2>\n<script src=\"%%(md5)s\" type=\"text/javascript\"></script>\n<script src=\"%%(md5manager)s\" type=\"text/javascript\"></script>\n<noscript>Javascript is needed!</noscript>\n<form name=\"login\" method=\"post\" action=\"%%(url)s\">\n    <p>\n        User:\n        <input name=\"user\" type=\"text\" value=\"\"><br />\n        Passwort:\n        <input name=\"pass\" type=\"password\" value=\"\"><br />\n        md5pass:\n        <input name=\"md5pass1\" value=\"\" type=\"text\" size=\"34\" maxlength=\"32\" />\n        <input name=\"md5pass2\" value=\"\" type=\"text\" size=\"34\" maxlength=\"32\" />\n        <br />\n        <input name=\"rnd\" type=\"hidden\" value=\"%%(rnd)s\">\n        <input name=\"use_md5login\" type=\"hidden\" value=\"0\">\n        <a href=\"javascript:md5login();\">MD5 LogIn</a>\n    </p>\n</form>\n<script type=\"text/javascript\">\n    document.login.user.focus();\n</script>\n','The Login Page.');
INSERT INTO `%(table_prefix)spages_internal` VALUES ('admin_sub_menu','none','<h2>Administration Sub-Menu</h2>\n%%(menu)s','Administration sub menu');
INSERT INTO `%(table_prefix)spages_internal` VALUES ('edit_style','none','<h2>Edit CSS stylesheet</h2>\n<form method=\"post\" action=\"%%(url)s\">\n    <p>\n        Name: <strong>&quot;%%(name)s&quot;</strong>:<br/>\n        <textarea wrap=\"off\" id=\"edit_style\" name=\"content\" style=\"width: 100%%%%;\" rows=\"25\" accept-charset=\"UTF-8\">%%(content)s</textarea><br />\n        Description: <input name=\"description\" type=\"text\" style=\"width: 100%%%%;\" value=\"%%(description)s\"><br />\n        <input type=\"submit\" name=\"Submit\" value=\"save\" />\n        <input type=\"reset\" name=\"abort\" onClick=\"javacript:window.location.href=\'%%(back)s\'\" value=\"abort\" />\n    </p>\n</form>','Page to edit a stylesheet');
INSERT INTO `%(table_prefix)spages_internal` VALUES ('edit_template','none','<h2>Edit template</h2>\n<form method=\"post\" action=\"%%(url)s\">\n    <p>\n        Name: <strong>&quot;%%(name)s&quot;</strong>:<br/>\n        <textarea wrap=\"off\" id=\"edit_style\" name=\"content\" style=\"width: 100%%%%;\" rows=\"25\" accept-charset=\"UTF-8\">%%(content)s</textarea><br />\n        Description: <input name=\"description\" type=\"text\" style=\"width: 100%%%%;\" value=\"%%(description)s\"><br />\n        <input type=\"submit\" name=\"Submit\" value=\"save\" />\n        <input type=\"reset\" name=\"abort\" onClick=\"javacript:window.location.href=\'%%(back)s\'\" value=\"abort\" />\n    </p>\n</form>','Page to edit a template');
INSERT INTO `%(table_prefix)spages_internal` VALUES ('edit_internal_page','none','<h2>Edit internal page</h2>\n<form method=\"post\" action=\"%%(url)s\">\n    <p>\n        Name: <strong>&quot;%%(name)s&quot;</strong>:<br/>\n        <textarea wrap=\"off\" id=\"edit_internal_page\" name=\"content\" style=\"width: 100%%%%;\" rows=\"25\" accept-charset=\"UTF-8\">%%(content)s</textarea><br />\n        Description: <input name=\"description\" type=\"text\" style=\"width: 100%%%%;\" value=\"%%(description)s\"><br />\n        <input type=\"submit\" name=\"Submit\" value=\"save\" />\n        <input type=\"reset\" name=\"abort\" onClick=\"javacript:window.location.href=\'%%(back)s\'\" value=\"abort\" />\n    </p>\n</form>\n<p><strong>Node:</strong> You may not delete internal Python tags, like: \'%%%%(name)s\'!</p>\n','Page to edit a internal page');
INSERT INTO `%(table_prefix)spages_internal` VALUES ('edit_page','none','%%(status_msg)s\n<style type=\"text/css\">\n    .edit_page {\n        line-height:1.5em;\n    }\n    .edit_page input, .edit_page select {\n        position: absolute;\n        left: 28em;\n\n    }\n    .resize_buttons a {\n        text-decoration:none;\n    }\n    #hr_textarea {\n        clear: both;\n        margin: 1px;\n        padding: 1px;\n        border: none;\n    }\n</style>\n<form name=\"login\" method=\"post\" action=\"%%(url)s\">\n  <p>Page: <strong>&quot;%%(name)s&quot;</strong>:<br>\n    <textarea id=\"page_content\" name=\"content\" rows=\"25\" accept-charset=\"UTF-8\">%%(content)s</textarea>\n    <hr id=\"hr_textarea\">\n    <span class=\"resize_buttons\">\n        <a href=\"JavaScript:resize_big();\" alt=\"bigger\">&nbsp;+&nbsp;</a>\n        <a href=\"JavaScript:resize_small();\">&nbsp;-&nbsp;</a>\n        &nbsp;&nbsp;\n    </span>\n    <input type=\"submit\" name=\"Submit\" value=\"preview\" />\n    <input type=\"submit\" name=\"Submit\" value=\"save\" />\n    <input type=\"reset\" name=\"abort\" onClick=\"javacript:window.location.href=\'?%%(name)s\'\" value=\"abort\" />\n    ||| <input type=\"submit\" name=\"Submit\" value=\"encode from DB\" />\n    <select name=\"encoding\" id=\"encoding\">%%(encoding_option)s</select>\n  </p>\n  <p>\n    trivial modifications: <input name=\"trivial\" type=\"checkbox\" id=\"trivial\" value=\"1\" />( If checked the side will not archived. )<br/>\n    Edit summary: <input name=\"summary\" type=\"text\" value=\"%%(summary)s\" id=\"summary\" size=\"50\" maxlength=\"50\" />\n  </p>\n  <h4>Page Details</h4>\n  <p class=\"edit_page\">\n    page name:    <input name=\"name\" type=\"text\" value=\"%%(name)s\" size=\"50\" maxlength=\"50\"><br/>\n    page title:   <input name=\"title\" type=\"text\" value=\"%%(title)s\" size=\"50\" maxlength=\"50\"><br/>\n    keywords:     <input name=\"keywords\" type=\"text\" value=\"%%(keywords)s\" size=\"70\" maxlength=\"255\"><br/>\n    description:  <input name=\"description\" type=\"text\" value=\"%%(description)s\" size=\"70\" maxlength=\"255\"><br/>\n  </p>\n  <h4>Page Controls</h4>\n  <p class=\"edit_page\">\n    Parent Page:    <select name=\"parent\" id=\"parent\">%%(parent_option)s</select><br/>\n    Template:       <select name=\"template\" id=\"template\">%%(template_option)s</select><br/>\n    Style:          <select name=\"style\">%%(style_option)s</select><br/>\n    Markup:         <select name=\"markup\">%%(markup_option)s</select><br/>\n    Page Owner:     <select name=\"ownerID\" id=\"ownerID\">%%(ownerID_option)s</select><br/>\n  </p>\n  <h4>Page Permissions</h4>\n  <p class=\"edit_page\">\n    Editable by Group:  <select name=\"permitEditGroupID\" id=\"permitEditGroupID\">%%(permitEditGroupID_option)s</select><br/>\n    Viewable by Group:  <select name=\"permitViewGroupID\" id=\"permitViewGroupID\">%%(permitViewGroupID_option)s</select><br/>\n    showlinks:          <input name=\"showlinks\" type=\"checkbox\" id=\"showlinks\" value=\"1\"%%(showlinks)s><br/>\n    permit view public: <input name=\"permitViewPublic\" type=\"checkbox\" id=\"permitViewPublic\" value=\"1\"%%(permitViewPublic)s><br/>\n  </p>\n</form>\n<script type=\"text/javascript\">\n    // Skript zum grÃƒÂ¶ÃƒÅ¸er und kleiner machen des Eingabefeldes\n    textarea = document.getElementById(\"page_content\");\n    hr_textarea = document.getElementById(\"hr_textarea\");\n    old_cols = textarea.cols;\n    old_rows = textarea.rows;\n    function resize_big() {\n        textarea.style.position = \"absolute\";\n        textarea.style.left = \"1em\";\n        textarea.style.top = \"1em\";\n        textarea.cols = textarea.cols*1.4;\n        textarea.rows = textarea.rows*1.75;\n\n        hr_textarea.style.margin = \"26em\";\n    }\n    function resize_small() {\n        textarea.style.position = \"relative\";\n        textarea.style.left = \"0px\";\n        textarea.style.top = \"0px\";\n        textarea.cols = old_cols;\n        textarea.rows = old_rows;\n        hr_textarea.style.margin = \"1px\";\n    }\n</script>\n','Page to edit a normal Content-Page');

--
-- Table structure for table `%(table_prefix)splugindata`
--

CREATE TABLE `%(table_prefix)splugindata` (
  `id` int(11) NOT NULL auto_increment,
  `pluginID` int(11) NOT NULL default '0',
  `varKey` varchar(50) NOT NULL default '',
  `linkID1` int(11) default NULL,
  `linkID2` int(11) default NULL,
  `varBoo1` tinyint(4) default NULL,
  `varBoo2` tinyint(4) default NULL,
  `varData1` varchar(255) default NULL,
  `varData2` varchar(255) default NULL,
  `varDateTime1` datetime default NULL,
  `varDateTime2` datetime default NULL,
  `varName` varchar(50) default NULL,
  `varContent` text,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `combinedKey` (`pluginID`,`varKey`)
);

--
-- Dumping data for table `%(table_prefix)splugindata`
--

INSERT INTO `%(table_prefix)splugindata` VALUES (1,6,'Bild006.jpg',NULL,NULL,NULL,NULL,'640','480',NULL,NULL,'Bild006.jpg',NULL);

--
-- Table structure for table `%(table_prefix)splugins`
--

CREATE TABLE `%(table_prefix)splugins` (
  `id` int(11) NOT NULL auto_increment,
  `filename` varchar(150) NOT NULL default '',
  `name` varchar(50) NOT NULL default '',
  `version` varchar(20) NOT NULL default '',
  `authorName` varchar(200) NOT NULL default '',
  `authorContact` varchar(200) NOT NULL default '',
  `description` text NOT NULL,
  `active` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `filename` (`filename`),
  UNIQUE KEY `name` (`name`),
  KEY `active` (`active`)
);

--
-- Dumping data for table `%(table_prefix)splugins`
--

INSERT INTO `%(table_prefix)splugins` VALUES (1,'markdown.php','Markdown','1.0','Markdown by John Gruber/Michel Fortin, implemented for lucidCMS by Zach Shelton','','Plugin to provide the Markdown Class for styling text without HTML.',0);
INSERT INTO `%(table_prefix)splugins` VALUES (2,'EasyLinks.php','EasyLinks','1.0','Zach Shelton','http://zachofalltrades.net','This plugin allows the author to easily create links to other pages using a very simple syntax.',1);
INSERT INTO `%(table_prefix)splugins` VALUES (3,'SiteMap.php','SiteMap','1.0','Zach Shelton','http://zachofalltrades.net','This plugin offers a replacement tag to generate a Site-Map for your site.',1);
INSERT INTO `%(table_prefix)splugins` VALUES (6,'ImageManager.php','Image Manager','1.0','Benjamin Birnbaum','ben@marlolake.com.au','A complete image manager for lucidCMS',1);
INSERT INTO `%(table_prefix)splugins` VALUES (7,'classTextile.php','Textile','1.0','Dean Allen','http://zachofalltrades.net','Textile was ported to PHP by Dean Allen, and implemented as a plugin for LucidCMS by Zach Shelton. The Textile class provides a simplified syntax for formatting text without HTML.',1);
INSERT INTO `%(table_prefix)splugins` VALUES (11,'backupMySQL.php','BackupMySQL','1.0','Zach Shelton','http://zachofalltrades.net','This plugin provides backup functionality for installations using a MySQL database.',0);
INSERT INTO `%(table_prefix)splugins` VALUES (13,'MenuMaker.php','Menu Maker','2.1','Benjamin Birnbaum','ben@marlolake.com.au','Provides customisable main, sub and peer menu tags for your site',1);

--
-- Table structure for table `%(table_prefix)spreferences`
--

CREATE TABLE `%(table_prefix)spreferences` (
  `id` int(11) NOT NULL auto_increment,
  `pluginID` int(11) NOT NULL default '0',
  `section` varchar(30) NOT NULL default '',
  `varName` varchar(30) NOT NULL default '',
  `name` varchar(50) NOT NULL default '',
  `description` text NOT NULL,
  `value` varchar(100) NOT NULL default '',
  `type` varchar(30) NOT NULL default 'text',
  PRIMARY KEY  (`id`),
  KEY `section` (`section`)
);

--
-- Dumping data for table `%(table_prefix)spreferences`
--

INSERT INTO `%(table_prefix)spreferences` VALUES (1,0,'core','defaultPageName','Default Page','This This is the default page that a site visitor will see if they arrive at your index.php without specifying a particular page.','1','pageSelect');
INSERT INTO `%(table_prefix)spreferences` VALUES (2,0,'core','defaultMarkup','Preferred Text Markup','This specifies what the default text markup parser will be for new pages. You can set it to the name of a plugin markup parser (\"textile\" and \"markdown\" are currently available), or \"none\".','textile','markupSelect');
INSERT INTO `%(table_prefix)spreferences` VALUES (3,0,'core','defaultTemplate','Default Template Name','This is the template that will be assigned to new pages when they are created.','1','templateSelect');
INSERT INTO `%(table_prefix)spreferences` VALUES (4,0,'core','defaultStyle','Default Style Name','This is the stylesheet taht will be assigned to new pages when they are created.','1','styleSelect');
INSERT INTO `%(table_prefix)spreferences` VALUES (5,0,'core','defaultShowLinks','Show Links default','This determines whether new pages are shown or hidden in navigation controls. Check to have pages shown, or leave unchecked to have new pages suppressed.','1','checkbox');
INSERT INTO `%(table_prefix)spreferences` VALUES (6,0,'core','defaultPermitPublic','Permit Public default','This determines whether new pages are publicly accessible, or require login. Check to make new pages automatically accessible, or leave un-checked to have new pages require login.','1','checkbox');
INSERT INTO `%(table_prefix)spreferences` VALUES (7,0,'core','siteOffline','Site Offline','If checked, whenever someone visits your site, rather then seeing the normal requested page, they will instead see the page that is specified in the \"Offline Page\" config item. If the user is currently logged in then they will see the requested page.','','checkbox');
INSERT INTO `%(table_prefix)spreferences` VALUES (8,0,'core','offlinePage','Offline Page','This is the page that a user will see if the \"Offline Site\" config item is checked.','1','pageSelect');
INSERT INTO `%(table_prefix)spreferences` VALUES (9,0,'core','formatDate','Date Format','Specify your preferred date display format (php time format).','%%d.%%m.%%Y','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (10,0,'core','formatTime','Time Format','Specify your preferred time display format (php time format).','%%H:%%M','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (11,0,'core','formatDateTime','DateTime Format','Specify your preferred date + time display format (php time format).','%%d.%%m.%%Y - %%H:%%M','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (12,0,'core','timezoneOffset','Timezone Offset','The number of hours difference between your server\'s time and the time you wish to have displayed (not necessarily offset from GMT).','0','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (13,0,'core','inactivityTimeout','Inactivitiy Timeout','The number of idle minutes before requiring user to log in again.','60','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (14,0,'core','rows','Editor - Rows','The number of rows to display in the editor.','25','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (15,0,'core','cols','Editor - Columns','The number of columns to display in the editor.','100','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (73,13,'MenuMaker','useTitles','Use Page Titles for Link Text','If this is checked, then page titles will be used for the text of links generated in menus. If there is no title, then the page name will be used for the link text.','1','checkbox');
INSERT INTO `%(table_prefix)spreferences` VALUES (72,13,'MenuMaker','peerReplace','Peer Menu to replace Sub Menu','If this is checked, then when there are no items to display in the \"sub menu\" then the \"sub menu\" will be replaced with the \"peer menu\". This is usually the desired menu behaviour.','1','checkbox');
INSERT INTO `%(table_prefix)spreferences` VALUES (71,13,'peerMenu','currentAfter','Peer Menu Current Page After','HTML placed after the currently displayed page link - if this is blank then \"Main Menu After\" will be used.','','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (70,13,'peerMenu','currentBefore','Peer Menu Current Page Before','HTML placed before the currently displayed page link - if this is blank then \"Main Menu Before\" will be used.','','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (69,13,'peerMenu','after','Peer Menu After','HTML placed after each individual menu item','</li>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (68,13,'peerMenu','before','Peer Menu Before','HTML placed before each individual menu item','<li>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (67,13,'peerMenu','finish','Peer Menu Finish','HTML placed at the end of the menu','</ul>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (66,13,'peerMenu','begin','Peer Menu Begin','HTML placed at the beginning of the menu','<ul>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (65,13,'subMenu','currentAfter','Sub Menu Current Page After','HTML placed after the currently displayed page link - if this is blank then \"Main Menu After\" will be used.','','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (62,13,'subMenu','before','Sub Menu Before','HTML placed before each individual menu item','<li>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (63,13,'subMenu','after','Sub Menu After','HTML placed after each individual menu item','</li>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (64,13,'subMenu','currentBefore','Sub Menu Current Page Before','HTML placed before the currently displayed page link - if this is blank then \"Main Menu Before\" will be used.','','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (60,13,'subMenu','begin','Sub Menu Begin','HTML placed at the beginning of the menu','<ul>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (61,13,'subMenu','finish','Sub Menu Finish','HTML placed at the end of the menu','</ul>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (39,6,'ImageManager','maxSize','Max Upload Size','Maximum size (in bytes) of an image you can upload','300000','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (38,6,'ImageManager','imageDir','Image Directory','This is the path to where the uploaded images will be stored. Please ensure that this directory exists and is writable by the web user.','./images/','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (59,13,'mainMenu','currentAfter','Main Menu Current Page After','HTML placed after the currently displayed page link - if this is blank then \"Main Menu After\" will be used.','','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (58,13,'mainMenu','currentBefore','Main Menu Current Page Before','HTML placed before the currently displayed page link - if this is blank then \"Main Menu Before\" will be used.','','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (57,13,'mainMenu','after','Main Menu After','HTML placed after each individual menu item','</li>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (55,13,'mainMenu','finish','Main Menu Finish','HTML placed at the end of the menu','</ul>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (56,13,'mainMenu','before','Main Menu Before','HTML placed before each individual menu item','<li>','text');
INSERT INTO `%(table_prefix)spreferences` VALUES (54,13,'mainMenu','begin','Main Menu Begin','HTML placed at the beginning of the menu','<ul>','text');

--
-- Table structure for table `%(table_prefix)ssession_data`
--

CREATE TABLE `%(table_prefix)ssession_data` (
  `session_id` varchar(32) NOT NULL default '',
  `timestamp` int(15) NOT NULL default '0',
  `ip` varchar(15) NOT NULL default '',
  `domain_name` varchar(50) NOT NULL default '',
  `session_data` text NOT NULL,
  PRIMARY KEY  (`session_id`),
  KEY `session_id` (`session_id`)
);

--
-- Dumping data for table `%(table_prefix)ssession_data`
--


--
-- Table structure for table `%(table_prefix)sstyles`
--

CREATE TABLE `%(table_prefix)sstyles` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `description` text NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
);

--
-- Dumping data for table `%(table_prefix)sstyles`
--

INSERT INTO `%(table_prefix)sstyles` VALUES (1,'main','the default stylesheet','/* Farben:\r\n\r\n#C9C573\r\n#B1B08B\r\n#FAFAFD\r\n#FFFFDB\r\n\r\n*/\r\n\r\n* {\r\n        /* Ãœbergreifende Schriftart */\r\n	color: #000000\r\n}\r\nbody {\r\n        /* Ãœbergreifende Schriftart */\r\n	font-family: tahoma, arial, sans-serif;\r\n	color: #000000;\r\n	font-size: 0.9em;\r\n	background-color: #C9C573;\r\n}\r\nhtml, body {\r\n	margin: 0;\r\n	padding: 0;\r\n}\r\ntextarea {\r\n        background-color: #FFFFF5;\r\n}\r\n#page_msg, pre, .code {\r\n	font-family: Courier New,Courier,monospace,mono;\r\n	background-color: #FAFAFD;\r\n	color: #000000;\r\n	padding: 10px;\r\n	border: 1px solid #C9C573;\r\n	font-size: 0.8em;\r\n}\r\n#page_msg {\r\n	border-color: #FF0000;\r\n	color: #AA0000;\r\n}\r\n#headline {\r\n	/* Ãœberschrift Ã¼ber die gesammte Seite */\r\n	font-size: 2em;\r\n	padding: 0.3em;\r\n	margin: 0px;\r\n	padding-left: 2em;\r\n	color: #FFFFFF;\r\n}\r\n#breadcrumbs {\r\n	/* Links aus dem breadcrumbs-Plugin */\r\n	width: 80%%;\r\n	margin:1em auto;\r\n	text-align:left;\r\n	max-width: 1024px;\r\n}\r\n#sidebar {\r\n	/* das gesammte MenÃ¯Â¿Â½ */\r\n	float: left;\r\n	width: 15em;\r\n	margin-top: 3em;\r\n	padding: 5px;\r\n	background-color: #FFFFDB;\r\n	border-top: 1px solid #8C8C96;\r\n	border-right: 1px solid #474763;\r\n	border-bottom: 1px solid #474763;\r\n	border-left: none;\r\n	margin-left: 0px;\r\n}\r\n#sidebar {\r\n	font-size: 0.9em;\r\n	color: #000000;\r\n	text-align:left;\r\n	padding:2px;\r\n}\r\n#sidebar a {\r\n	padding: 0px 0px 0px 4px;\r\n	display: block;\r\n	text-decoration:none;\r\n}\r\n#sidebar a:hover, #sidebar a.current {\r\n	/* hover + Aktuell angeklickter MenÃ¯Â¿Â½punkt */\r\n\r\n	background-color: #C9C573;\r\n	color: #FFFFFF;\r\n}\r\n#sidebar ul {\r\n\r\n	margin: 5px 0px 5px 10px;\r\n	padding: 5px 0px 5px 5px;\r\n	list-style-type: none;\r\n	border-bottom: 1px solid #C9C573;\r\n	border-top: 1px solid #C9C573;\r\n}\r\n#sidebar li {\r\n	margin: 0px;\r\n	padding: 0px;\r\n	padding-right: 5px;\r\n	padding-left: 5px;\r\n	border-top: 0px none;\r\n	border-right: 0px none;\r\n	border-left: 0px none;\r\n	white-space: nowrap;\r\n}\r\n#main {\r\n	/* Rahmen fÃ¼r main-content + footer_nav */\r\n	margin-left: 11em;\r\n	margin-right: 40px;\r\n	background-color: #FFFFE5;\r\n	padding: 1em 6em 0.5em;\r\n	max-width:1024px\r\n}\r\n#main-content {\r\n	min-height: 500px;\r\n}\r\n#main-content h2 {\r\n	border-bottom: 1px solid #000000;\r\n}\r\n#nav_footer, #nav_link {\r\n	font-size: 0.6em;\r\n}\r\n#nav_footer p, #nav_footer a, #nav_link a, #nav_link {\r\n	/*\r\n	nav_footer - ZusÃ¤tzliche Navigation + Ã„nderungs-Datum im Footer\r\n	nav_link   - ZusÃ¤tzliche Navigation oben\r\n	*/\r\n	color: #B1B08B;\r\n}\r\n#nav_footer p {\r\n	/* Letzte Ã„nderung */\r\n	text-align: right;\r\n}\r\n#nav_footer a {\r\n	/* top-Link */\r\n	text-align: right;\r\n}\r\n#footer, #footer a {\r\n	color: #FFFFDB;\r\n	text-decoration:none;\r\n}\r\n#footer {\r\n	text-align: center;\r\n	font-size: 0.6em;\r\n	width: auto;\r\n	margin-top:35px;\r\n	border-top: 2px solid #FFFFDB;\r\n}\r\n/*\r\n-----------------------------------------------------\r\nZusatzmodule\r\n-----------------------------------------------------\r\n*/\r\n.Gallery ul {\r\n	text-align: center;\r\n	margin: 0px;\r\n	padding: 0px;\r\n}\r\n.Gallery li {\r\n	float: left;\r\n	border: 1px solid #EAECFF;\r\n	height: 150px;\r\n	width: auto;\r\n	text-align: center;\r\n	margin: 5px;\r\n	padding: 5px;\r\n	list-style-type: none;\r\n	background-color: #EDF1FF;\r\n}\r\n.clear {\r\n	clear: both;\r\n	margin: 5px;\r\n	padding: 5px;\r\n	border: none;\r\n}\r\n/*\r\n-----------------------------------------------------\r\nPage Edit\r\n-----------------------------------------------------\r\n*/\r\n#page_content {\r\n    width: 100%%;\r\n}\r\n/*\r\n-----------------------------------------------------\r\nSite Map\r\n-----------------------------------------------------\r\n*/\r\n#SiteMap ul {\r\n  margin-top: 5px;\r\n  margin-bottom: 5px;\r\n  list-style-type: none;\r\n}\r\n#SiteMap li {\r\n  margin-top: 2px;\r\n  margin-bottom: 2px;\r\n}\r\n#SiteMap .deep_0 {\r\n  margin-top: 1em;\r\n  border-bottom: 1px solid #C9C573;\r\n}\r\n#SiteMap .deep_0 a {\r\n  text-decoration:none;\r\n}');
INSERT INTO `%(table_prefix)sstyles` VALUES (2,'none','This is a blank stylesheet.','');

--
-- Table structure for table `%(table_prefix)stemplates`
--

CREATE TABLE `%(table_prefix)stemplates` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `description` text NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
);

--
-- Dumping data for table `%(table_prefix)stemplates`
--

INSERT INTO `%(table_prefix)stemplates` VALUES (1,'basic','default template','<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"xhtml1-strict.dtd\">\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\r\n<head>\r\n<title><lucidTag:page_title/></title>\r\n<meta name=\"robots\"                    content=\"<lucidTag:robots/>\" />\r\n<meta name=\"keywords\"                  content=\"<lucidTag:page_keywords/>\" />\r\n<meta name=\"description\"               content=\"<lucidTag:page_description/>\" />\r\n<meta name=\"Author\"                    content=\"PyLucidCMS\" />\r\n<meta name=\"DC.Date\"                   content=\"<lucidTag:page_last_modified/>\" />\r\n<meta name=\"DC.Date.created\"           content=\"<lucidTag:page_datetime/>\" />\r\n<meta name=\"DC.Language\"               content=\"de\" />\r\n<meta http-equiv=\"content-language\"    content=\"de\" />\r\n<meta http-equiv=\"Content-Type\"        content=\"text/html; charset=utf-8\" />\r\n<meta name=\"MSSmartTagsPreventParsing\" content=\"TRUE\" />\r\n<meta http-equiv=\"imagetoolbar\"        content=\"no\" />\r\n<link rel=\"contents\" title=\"Inhaltsverzeichnis\" href=\"?SideMap\" />\r\n<lucidTag:page_style_link/>\r\n</head>\r\n<body>\r\n<a id=\"top\" name=\"top\"></a>\r\n<h2 id=\"headline\">PyLucid CMS</h2>\r\n<div id=\"sidebar\">\r\n<lucidTag:main_menu/>\r\n</div>\r\n<div id=\"main\">\r\n	<div id=\"main-content\">\r\n		<h2><lucidTag:page_title/></h2>\r\n        <lucidTag:page_msg/>\r\n<lucidTag:front_menu/>\r\n		<p id=\"nav_link\">\r\n		<lucidTag:back_links/>\r\n		</p>\r\n		<lucidTag:page_body/>\r\n	</div>\r\n	<hr class=\"clear\" />\r\n	<div id=\"nav_footer\">\r\n		<p>Letzte Ã„nderung: <lucidTag:page_last_modified/></p>\r\n		<a href=\"#top\">^ nach oben</a>\r\n	</div>\r\n</div>\r\n<div id=\"footer\">\r\n<lucidTag:powered_by/> | <lucidTag:script_login/> | Rendered in <lucidTag:script_duration/> sec.\r\n</div>\r\n<script src=\"/LinkManager.js\" type=\"text/javascript\"></script>\r\n</body>\r\n</html>');
INSERT INTO `%(table_prefix)stemplates` VALUES (2,'none','This is a blank template -- which is actually kind of useful for some purposes.','');

--
-- Table structure for table `%(table_prefix)suser_group`
--

CREATE TABLE `%(table_prefix)suser_group` (
  `id` int(11) NOT NULL auto_increment,
  `userID` int(11) NOT NULL default '0',
  `groupID` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `groupID` (`groupID`),
  KEY `userID` (`userID`)
);

--
-- Dumping data for table `%(table_prefix)suser_group`
--


--
-- Table structure for table `%(table_prefix)susers`
--

CREATE TABLE `%(table_prefix)susers` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `realName` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  `admin` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
);

--
-- Dumping data for table `%(table_prefix)susers`
--






