CREATE TABLE `%(table_prefix)stemplate_engines` (`id` tinyint(1) NOT NULL auto_increment,`name` varchar(50) NOT NULL default '',PRIMARY KEY  (`id`)) COMMENT='Liste of available template engines (manually created!)';
INSERT INTO `%(table_prefix)stemplate_engines` VALUES (1,'None');
INSERT INTO `%(table_prefix)stemplate_engines` VALUES (2,'string formatting');
INSERT INTO `%(table_prefix)stemplate_engines` VALUES (3,'TAL');
