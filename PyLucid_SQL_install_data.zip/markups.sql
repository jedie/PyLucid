CREATE TABLE `%(table_prefix)smarkups` (`id` int(11) NOT NULL auto_increment,`name` varchar(50) NOT NULL default '',PRIMARY KEY  (`id`));
INSERT INTO `%(table_prefix)smarkups` VALUES (1,'string formatting');
INSERT INTO `%(table_prefix)smarkups` VALUES (2,'textile');
INSERT INTO `%(table_prefix)smarkups` VALUES (3,'TAL');
