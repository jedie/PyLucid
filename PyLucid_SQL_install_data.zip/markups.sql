CREATE TABLE `%(table_prefix)smarkups` (`id` int(11) NOT NULL auto_increment,`name` varchar(50) NOT NULL default '',PRIMARY KEY  (`id`));
INSERT INTO `%(table_prefix)smarkups` VALUES (1,'none');
INSERT INTO `%(table_prefix)smarkups` VALUES (2,'textile');
