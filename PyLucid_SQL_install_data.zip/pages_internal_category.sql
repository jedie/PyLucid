CREATE TABLE `%(table_prefix)spages_internal_category` (`id` int(11) NOT NULL auto_increment,`name` varchar(50) NOT NULL default '',`position` int(11) NOT NULL default '0',PRIMARY KEY  (`id`));
INSERT INTO `%(table_prefix)spages_internal_category` VALUES (1,'page management',0);
INSERT INTO `%(table_prefix)spages_internal_category` VALUES (2,'edit look',2);
INSERT INTO `%(table_prefix)spages_internal_category` VALUES (3,'user handling',4);
INSERT INTO `%(table_prefix)spages_internal_category` VALUES (4,'features',6);
INSERT INTO `%(table_prefix)spages_internal_category` VALUES (5,'admin area',8);
