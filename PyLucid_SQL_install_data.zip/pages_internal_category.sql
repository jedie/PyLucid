CREATE TABLE `%(table_prefix)spages_internal_category` (`id` int(11) NOT NULL auto_increment,`name` varchar(50) NOT NULL default '',`position` int(11) NOT NULL default '0',PRIMARY KEY  (`id`));
