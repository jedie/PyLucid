CREATE TABLE `$$session_data` (  `session_id` varchar(32) NOT NULL default '',  `timestamp` int(15) NOT NULL default '0',  `ip` varchar(15) NOT NULL default '',  `domain_name` varchar(50) NOT NULL default '',  `session_data` text NOT NULL,  PRIMARY KEY  (`session_id`),  KEY `session_id` (`session_id`)) COMMENT='session management data';

