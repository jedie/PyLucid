CREATE TABLE `$$pages_internal` (  `name` varchar(50) NOT NULL default '',  `plugin_id` tinyint(4) unsigned NOT NULL default '0',  `method_id` tinyint(4) unsigned NOT NULL default '0',  `template_engine` tinyint(4) unsigned default NULL,  `markup` tinyint(4) unsigned default NULL,  `lastupdatetime` datetime NOT NULL default '0000-00-00 00:00:00',  `lastupdateby` int(11) NOT NULL default '0',  `content_html` text NOT NULL,  `content_js` text NOT NULL,  `content_css` text NOT NULL,  `description` text NOT NULL,  PRIMARY KEY  (`name`)) COMMENT='internal page storage';


