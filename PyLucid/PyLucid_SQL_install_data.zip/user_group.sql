CREATE TABLE `$$user_group` (  `id` int(11) NOT NULL auto_increment,  `userID` int(11) NOT NULL default '0',  `groupID` int(11) NOT NULL default '0',  `lastupdatetime` datetime NOT NULL default '0000-00-00 00:00:00',  `lastupdateby` int(11) default NULL,  `createtime` datetime NOT NULL default '0000-00-00 00:00:00',  PRIMARY KEY  (`id`),  KEY `groupID` (`groupID`),  KEY `userID` (`userID`)) COMMENT='not used yet!';


